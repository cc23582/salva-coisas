package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto;

public record LoginDTO(
        String login,
        String senha
) {
}