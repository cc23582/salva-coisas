package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Laboratorio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LaboratorioRepository
        extends JpaRepository<Laboratorio, Integer> {

    Optional<Laboratorio> findByCodigo(String codigo);

    List<Laboratorio> findByNomeContainingIgnoreCase(String nome);

    List<Laboratorio> findByCapacidade(Integer capacidade);

    List<Laboratorio> findByLocalizacaoContainingIgnoreCase(String localizacao);

    List<Laboratorio> findByStatus(String status);

    Optional<Laboratorio> findByNomeAndCapacidadeAndLocalizacao(
            String nome,
            Integer capacidade,
            String localizacao
    );
}
