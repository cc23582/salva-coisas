package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller;

public class LaboratorioController {
}
