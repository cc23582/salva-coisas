package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.service;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Reserva;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Sala;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.StatusReserva;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Usuario;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.ReservaRepository;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.SalaRepository;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.StatusReservaRepository;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import java.time.LocalDateTime;

import org.springframework.scheduling.annotation.Scheduled;


@Service
public class ReservaService {

    private final ReservaRepository reservaRepository;
    private final UsuarioRepository usuarioRepository;
    private final SalaRepository salaRepository;
    private final StatusReservaRepository statusReservaRepository;

    public ReservaService(
            ReservaRepository reservaRepository,
            UsuarioRepository usuarioRepository,
            SalaRepository salaRepository,
            StatusReservaRepository statusReservaRepository
    ) {
        this.reservaRepository = reservaRepository;
        this.usuarioRepository = usuarioRepository;
        this.salaRepository = salaRepository;
        this.statusReservaRepository = statusReservaRepository;
    }

    public Reserva cadastrarReserva(
            Reserva reserva,
            Integer usuarioId,
            Integer salaId,
            Integer statusReservaId
    ) {

        validarDatasEHorarios(reserva);

        Usuario usuario = usuarioRepository.findById(usuarioId.longValue())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Usuário não encontrado."
                        )
                );

        Sala sala = salaRepository.findById(salaId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Sala não encontrada."
                        )
                );

        StatusReserva statusReserva =
                statusReservaRepository.findById(statusReservaId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Status da reserva não encontrado."
                                )
                        );

        List<Reserva> conflitos =
                reservaRepository.buscarConflitos(
                        sala.getId(),
                        reserva.getDataInicial(),
                        reserva.getHoraInicial(),
                        reserva.getHoraFinal()
                );

        if (!conflitos.isEmpty()) {
            throw new IllegalArgumentException(
                    "Já existe uma reserva para esta sala no horário informado."
            );
        }

        reserva.setUsuario(usuario);
        reserva.setSala(sala);
        reserva.setStatusReserva(statusReserva);

        return reservaRepository.save(reserva);
    }

    private void validarDatasEHorarios(Reserva reserva) {

        if (reserva.getDataFinal()
                .isBefore(reserva.getDataInicial())) {

            throw new IllegalArgumentException(
                    "A data final não pode ser anterior à data inicial."
            );
        }

        if (reserva.getDataFinal()
                .isAfter(reserva.getDataInicial())) {

            throw new IllegalArgumentException(
                    "A reserva não pode ultrapassar um dia."
            );
        }

        if (!reserva.getHoraFinal()
                .isAfter(reserva.getHoraInicial())) {

            throw new IllegalArgumentException(
                    "A hora final deve ser posterior à hora inicial."
            );
        }
    }

    public List<Reserva> pesquisarReservas(

            String codigoRecurso,
            String nomeRecurso,
            LocalDate dataInicial,
            LocalDate dataFinal,
            LocalTime horaInicial,
            LocalTime horaFinal,
            String cpfUsuario,
            String nomeUsuario,
            String statusReserva

    ) {

        return reservaRepository.findAll()
                .stream()

                .filter(reserva ->
                        codigoRecurso == null
                                || reserva.getSala()
                                .getCodigo()
                                .equalsIgnoreCase(
                                        codigoRecurso
                                )
                )

                .filter(reserva ->
                        nomeRecurso == null
                                || reserva.getSala()
                                .getNome()
                                .toLowerCase()
                                .contains(
                                        nomeRecurso.toLowerCase()
                                )
                )

                .filter(reserva ->
                        dataInicial == null
                                || !reserva
                                .getDataInicial()
                                .isBefore(dataInicial)
                )

                .filter(reserva ->
                        dataFinal == null
                                || !reserva
                                .getDataFinal()
                                .isAfter(dataFinal)
                )

                .filter(reserva ->
                        horaInicial == null
                                || !reserva
                                .getHoraInicial()
                                .isBefore(horaInicial)
                )

                .filter(reserva ->
                        horaFinal == null
                                || !reserva
                                .getHoraFinal()
                                .isAfter(horaFinal)
                )

                .filter(reserva ->
                        cpfUsuario == null
                                || reserva.getUsuario()
                                .getCpf()
                                .equals(cpfUsuario)
                )

                .filter(reserva ->
                        nomeUsuario == null
                                || reserva.getUsuario()
                                .getNomeCompleto()
                                .toLowerCase()
                                .contains(
                                        nomeUsuario.toLowerCase()
                                )
                )

                .filter(reserva ->
                        statusReserva == null
                                || reserva.getStatusReserva()
                                .getNome()
                                .equalsIgnoreCase(statusReserva)
                )

                .toList();
    }

    public Reserva atualizarReserva(
            Integer id,
            Reserva reserva,
            Integer usuarioId,
            Integer salaId,
            Integer statusReservaId
    ) {

        Reserva existente = reservaRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Reserva não encontrada."
                        )
                );

        validarDatasEHorarios(reserva);

        Usuario usuario = usuarioRepository.findById(usuarioId.longValue())
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Usuário não encontrado."
                        )
                );

        Sala sala = salaRepository.findById(salaId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Sala não encontrada."
                        )
                );

        StatusReserva statusReserva =
                statusReservaRepository.findById(statusReservaId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Status da reserva não encontrado."
                                )
                        );

        List<Reserva> conflitos =
                reservaRepository.buscarConflitos(
                        sala.getId(),
                        reserva.getDataInicial(),
                        reserva.getHoraInicial(),
                        reserva.getHoraFinal()
                );

        boolean possuiOutroConflito = conflitos.stream()
                .anyMatch(r -> !r.getId().equals(id));

        if (possuiOutroConflito) {
            throw new IllegalArgumentException(
                    "Já existe uma reserva para esta sala no horário informado."
            );
        }

        existente.setDataInicial(reserva.getDataInicial());
        existente.setDataFinal(reserva.getDataFinal());
        existente.setHoraInicial(reserva.getHoraInicial());
        existente.setHoraFinal(reserva.getHoraFinal());
        existente.setUsuario(usuario);
        existente.setSala(sala);
        existente.setStatusReserva(statusReserva);

        return reservaRepository.save(existente);
    }

    public Reserva cancelarReserva(Integer id) {

        Reserva reserva = reservaRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Reserva não encontrada."
                        )
                );

        LocalDateTime inicioReserva = LocalDateTime.of(
                reserva.getDataInicial(),
                reserva.getHoraInicial()
        );

        LocalDateTime limiteCancelamento =
                inicioReserva.minusHours(24);

        LocalDateTime agora = LocalDateTime.now();

        if (agora.isAfter(limiteCancelamento)) {
            throw new IllegalArgumentException(
                    "A reserva só pode ser cancelada com antecedência mínima de 24 horas."
            );
        }

        StatusReserva statusCancelada =
                statusReservaRepository.findByNome("CANCELADA")
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Status CANCELADA não encontrado."
                                )
                        );

        reserva.setStatusReserva(statusCancelada);

        return reservaRepository.save(reserva);
    }

    @Scheduled(fixedRate = 60000)
    public void concluirReservasAutomaticamente() {

        LocalDateTime agora = LocalDateTime.now();

        StatusReserva statusAtiva =
                statusReservaRepository.findByNome("ATIVA")
                        .orElse(null);

        StatusReserva statusConcluida =
                statusReservaRepository.findByNome("CONCLUÍDA")
                        .orElse(null);

        if (statusAtiva == null || statusConcluida == null) {
            return;
        }

        List<Reserva> reservas = reservaRepository.findAll();

        for (Reserva reserva : reservas) {

            if (!reserva.getStatusReserva()
                    .getId()
                    .equals(statusAtiva.getId())) {
                continue;
            }

            LocalDateTime fimReserva = LocalDateTime.of(
                    reserva.getDataFinal(),
                    reserva.getHoraFinal()
            );

            if (!agora.isBefore(fimReserva.plusMinutes(1))) {

                reserva.setStatusReserva(statusConcluida);

                reservaRepository.save(reserva);
            }
        }
    }
}
