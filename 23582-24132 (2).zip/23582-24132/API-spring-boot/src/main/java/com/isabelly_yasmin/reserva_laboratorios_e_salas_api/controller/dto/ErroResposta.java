package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto;

public record ErroResposta(
        int status,
        String mensagem
) {

    public static ErroResposta conflito(String mensagem) {
        return new ErroResposta(409, mensagem);
    }
}