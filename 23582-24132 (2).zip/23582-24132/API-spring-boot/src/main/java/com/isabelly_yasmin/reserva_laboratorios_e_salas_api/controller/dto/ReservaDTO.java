package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Reserva;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;
import java.time.LocalTime;

public record ReservaDTO(

        @NotNull(message = "Data inicial é obrigatória")
        LocalDate dataInicial,

        @NotNull(message = "Data final é obrigatória")
        LocalDate dataFinal,

        @NotNull(message = "Hora inicial é obrigatória")
        LocalTime horaInicial,

        @NotNull(message = "Hora final é obrigatória")
        LocalTime horaFinal,

        @NotNull(message = "Usuário é obrigatório")
        Integer usuarioId,

        @NotNull(message = "Sala é obrigatória")
        Integer salaId,

        @NotNull(message = "Status da reserva é obrigatório")
        Integer statusReservaId
) {

    public Reserva mapearDadosParaEntidade() {

        Reserva reserva = new Reserva();

        reserva.setDataInicial(dataInicial);
        reserva.setDataFinal(dataFinal);
        reserva.setHoraInicial(horaInicial);
        reserva.setHoraFinal(horaFinal);

        return reserva;
    }
}
