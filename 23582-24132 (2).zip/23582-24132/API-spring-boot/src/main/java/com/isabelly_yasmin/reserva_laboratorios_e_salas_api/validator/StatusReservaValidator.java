package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.validator;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.exceptions.RegistroDuplicadoException;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Laboratorio;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.LaboratorioRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class LaboratorioValidator {

    private final LaboratorioRepository laboratorioRepository;

    public LaboratorioValidator(
            LaboratorioRepository laboratorioRepository
    ) {
        this.laboratorioRepository = laboratorioRepository;
    }

    public void validar(Laboratorio laboratorio) {

        Optional<Laboratorio> laboratorioEncontrado =
                laboratorioRepository.findByCodigo(
                        laboratorio.getCodigo()
                );

        if (laboratorioEncontrado.isPresent()
                && (laboratorio.getId() == null
                || !laboratorio.getId().equals(
                laboratorioEncontrado.get().getId()
        ))) {

            throw new RegistroDuplicadoException(
                    "Código do laboratório já cadastrado"
            );
        }
    }
}
