package com.isabelly_yasmin.reserva_laboratorios_e_salas_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class ReservaLaboratoriosESalasApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(
				ReservaLaboratoriosESalasApiApplication.class,
				args
		);
	}
}