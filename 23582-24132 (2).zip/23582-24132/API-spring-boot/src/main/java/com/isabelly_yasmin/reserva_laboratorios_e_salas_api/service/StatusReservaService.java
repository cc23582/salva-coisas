package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.service;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.StatusReserva;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.StatusReservaRepository;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.validator.StatusReservaValidator;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StatusReservaService {

    private final StatusReservaRepository statusReservaRepository;
    private final StatusReservaValidator statusReservaValidator;

    public StatusReservaService(
            StatusReservaRepository statusReservaRepository,
            StatusReservaValidator statusReservaValidator
    ) {
        this.statusReservaRepository =
                statusReservaRepository;

        this.statusReservaValidator =
                statusReservaValidator;
    }

    public StatusReserva inserir(StatusReserva statusReserva) {

        statusReservaValidator.validar(statusReserva);

        return statusReservaRepository.save(statusReserva);
    }

    public Optional<StatusReserva> buscarPorId(Integer id) {

        return statusReservaRepository.findById(id);
    }

    public List<StatusReserva> listar() {

        return statusReservaRepository.findAll();
    }

    public StatusReserva atualizar(StatusReserva statusReserva) {

        if (statusReserva.getId() == null) {

            throw new IllegalArgumentException(
                    "Não existe o STATUS DE RESERVA com o ID informado."
            );
        }

        statusReservaValidator.validar(statusReserva);

        return statusReservaRepository.save(statusReserva);
    }

    public void excluir(Integer id) {

        if (!statusReservaRepository.existsById(id)) {

            throw new IllegalArgumentException(
                    "Status de reserva não encontrado."
            );
        }

        statusReservaRepository.deleteById(id);
    }
}
