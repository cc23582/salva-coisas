package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.StatusReserva;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface StatusReservaRepository
        extends JpaRepository<StatusReserva, Integer> {

    Optional<StatusReserva> findByNome(String nome);

    Optional<StatusReserva> findByCodigo(Integer codigo);
}
