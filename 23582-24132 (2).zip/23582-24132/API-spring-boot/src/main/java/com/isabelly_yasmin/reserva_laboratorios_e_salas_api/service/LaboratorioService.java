package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.service;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Laboratorio;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.LaboratorioRepository;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.validator.LaboratorioValidator;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LaboratorioService {

    private final LaboratorioRepository laboratorioRepository;
    private final LaboratorioValidator laboratorioValidator;

    public LaboratorioService(
            LaboratorioRepository laboratorioRepository,
            LaboratorioValidator laboratorioValidator
    ) {
        this.laboratorioRepository = laboratorioRepository;
        this.laboratorioValidator = laboratorioValidator;
    }

    public Laboratorio inserirLaboratorio(
            Laboratorio laboratorio
    ) {

        laboratorioValidator.validar(laboratorio);

        return laboratorioRepository.save(laboratorio);
    }

    public Optional<Laboratorio> pegarDadosLaboratorioPorId(
            Integer id
    ) {

        return laboratorioRepository.findById(id);
    }

    public Laboratorio atualizarLaboratorio(
            Laboratorio laboratorio
    ) {

        if (laboratorio.getId() == null) {
            throw new IllegalArgumentException(
                    "Não existe laboratório com o ID informado."
            );
        }

        laboratorioValidator.validar(laboratorio);

        return laboratorioRepository.save(laboratorio);
    }

    public void excluirLaboratorioPorId(Integer id) {

        laboratorioRepository.deleteById(id);
    }

    public List<Laboratorio> pesquisar(
            String codigo,
            String nome,
            Integer capacidade,
            String localizacao,
            String status
    ) {

        List<Laboratorio> resultado =
                laboratorioRepository.findAll();

        return resultado.stream()

                .filter(laboratorio ->
                        codigo == null ||
                                laboratorio.getCodigo()
                                        .toLowerCase()
                                        .contains(
                                                codigo.toLowerCase()
                                        )
                )

                .filter(laboratorio ->
                        nome == null ||
                                laboratorio.getNome()
                                        .toLowerCase()
                                        .contains(
                                                nome.toLowerCase()
                                        )
                )

                .filter(laboratorio ->
                        capacidade == null ||
                                laboratorio.getCapacidade()
                                        .equals(capacidade)
                )

                .filter(laboratorio ->
                        localizacao == null ||
                                laboratorio.getLocalizacao()
                                        .toLowerCase()
                                        .contains(
                                                localizacao.toLowerCase()
                                        )
                )

                .filter(laboratorio ->
                        status == null ||
                                laboratorio.getStatus()
                                        .equalsIgnoreCase(status)
                )

                .toList();
    }
}
