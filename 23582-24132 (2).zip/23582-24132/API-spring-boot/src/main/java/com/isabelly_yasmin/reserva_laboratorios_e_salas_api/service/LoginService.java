package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.service;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Usuario;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    private final UsuarioRepository usuarioRepository;

    public LoginService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public Usuario realizarLogin(String login, String senha) {

        if (login == null || login.isBlank()) {
            throw new IllegalArgumentException("Login é obrigatório");
        }

        if (senha == null || senha.isBlank()) {
            throw new IllegalArgumentException("Senha é obrigatória");
        }

        Usuario usuario = usuarioRepository.findByLogin(login)
                .orElseThrow(() ->
                        new RuntimeException("Login ou senha inválido!")
                );

        if (!usuario.getSenha().equals(senha)) {
            throw new RuntimeException("Login ou senha inválido!");
        }

        return usuario;
    }
}
