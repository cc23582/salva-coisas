package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto;

public record LoginRespostaDTO(
        Long id,
        String login,
        String nomeCompleto
) {
}
