package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.StatusReserva;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record StatusReservaDTO(
        Integer id,

        @NotNull(message = "Campo obrigatório")
        Integer codigo,

        @NotBlank(message = "Campo obrigatório")
        @Size(
                min = 15,
                max = 20,
                message = "Quantidade de caracteres incorreta!"
        )
        String nome
) {

    public StatusReserva mapearDadosParaEntidade() {

        StatusReserva statusReserva =
                new StatusReserva();

        statusReserva.setCodigo(this.codigo());
        statusReserva.setNome(this.nome());

        return statusReserva;
    }
}
