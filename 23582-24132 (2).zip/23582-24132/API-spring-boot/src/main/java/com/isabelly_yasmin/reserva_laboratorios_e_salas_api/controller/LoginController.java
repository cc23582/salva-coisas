package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto.LoginDTO;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto.LoginRespostaDTO;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.Usuario;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.service.LoginService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login")
public class LoginController {

    private final LoginService loginService;

    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping
    public ResponseEntity<LoginRespostaDTO> login(
            @RequestBody LoginDTO dto
    ) {

        Usuario usuario = loginService.realizarLogin(
                dto.login(),
                dto.senha()
        );

        LoginRespostaDTO resposta = new LoginRespostaDTO(
                usuario.getId(),
                usuario.getLogin(),
                usuario.getNomeCompleto()
        );

        return ResponseEntity.ok(resposta);
    }
}