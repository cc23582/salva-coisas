package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.exceptions;

public class RegistroDuplicadoException extends RuntimeException {

    public RegistroDuplicadoException(String mensagem) {
        super(mensagem);
    }
}