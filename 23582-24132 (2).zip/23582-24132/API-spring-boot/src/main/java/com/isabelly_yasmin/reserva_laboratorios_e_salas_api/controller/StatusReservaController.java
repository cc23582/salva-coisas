package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller;

import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto.ErroResposta;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.controller.dto.StatusReservaDTO;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.exceptions.RegistroDuplicadoException;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.model.StatusReserva;
import com.isabelly_yasmin.reserva_laboratorios_e_salas_api.service.StatusReservaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/status-reservas")
public class StatusReservaController {

    private final StatusReservaService statusReservaService;

    public StatusReservaController(
            StatusReservaService statusReservaService
    ) {
        this.statusReservaService =
                statusReservaService;
    }

    @PostMapping
    public ResponseEntity<Object> incluir(
            @RequestBody @Valid StatusReservaDTO dto
    ) {

        try {

            StatusReserva statusReserva =
                    dto.mapearDadosParaEntidade();

            StatusReserva salvo =
                    statusReservaService.inserir(
                            statusReserva
                    );

            StatusReservaDTO resposta =
                    new StatusReservaDTO(
                            salvo.getId(),
                            salvo.getCodigo(),
                            salvo.getNome()
                    );

            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(resposta);

        } catch (RegistroDuplicadoException e) {

            var erroDTO =
                    ErroResposta.conflito(
                            e.getMessage()
                    );

            return ResponseEntity
                    .status(erroDTO.status())
                    .body(erroDTO);
        }
    }

    @GetMapping
    public ResponseEntity<List<StatusReservaDTO>> listar() {

        List<StatusReservaDTO> lista =
                statusReservaService.listar()
                        .stream()
                        .map(status ->
                                new StatusReservaDTO(
                                        status.getId(),
                                        status.getCodigo(),
                                        status.getNome()
                                )
                        )
                        .collect(Collectors.toList());

        return ResponseEntity.ok(lista);
    }

    @GetMapping("/{id}")
    public ResponseEntity<StatusReservaDTO> buscarPorId(
            @PathVariable Integer id
    ) {

        Optional<StatusReserva> optional =
                statusReservaService.buscarPorId(id);

        if (optional.isEmpty()) {
            return ResponseEntity
                    .notFound()
                    .build();
        }

        StatusReserva status =
                optional.get();

        return ResponseEntity.ok(
                new StatusReservaDTO(
                        status.getId(),
                        status.getCodigo(),
                        status.getNome()
                )
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<Object> atualizar(
            @PathVariable Integer id,
            @RequestBody @Valid StatusReservaDTO dto
    ) {

        try {

            Optional<StatusReserva> optional =
                    statusReservaService.buscarPorId(id);

            if (optional.isEmpty()) {
                return ResponseEntity
                        .notFound()
                        .build();
            }

            StatusReserva status =
                    optional.get();

            status.setCodigo(dto.codigo());
            status.setNome(dto.nome());

            StatusReserva atualizado =
                    statusReservaService.atualizar(status);

            return ResponseEntity.ok(
                    new StatusReservaDTO(
                            atualizado.getId(),
                            atualizado.getCodigo(),
                            atualizado.getNome()
                    )
            );

        } catch (RegistroDuplicadoException e) {

            var erroDTO =
                    ErroResposta.conflito(
                            e.getMessage()
                    );

            return ResponseEntity
                    .status(erroDTO.status())
                    .body(erroDTO);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(
            @PathVariable Integer id
    ) {

        Optional<StatusReserva> optional =
                statusReservaService.buscarPorId(id);

        if (optional.isEmpty()) {
            return ResponseEntity
                    .notFound()
                    .build();
        }

        statusReservaService.excluir(id);

        return ResponseEntity
                .noContent()
                .build();
    }
}
