package com.isabelly_yasmin.reserva_laboratorios_e_salas_api.validator;

public class LaboratorioValidator {
}
